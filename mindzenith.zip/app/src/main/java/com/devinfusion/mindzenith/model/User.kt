package com.devinfusion.mindzenith.model

data class User(val userName : String? = "",val uid : String? = "",val photoUrl : String? = "",val email: String? = "")